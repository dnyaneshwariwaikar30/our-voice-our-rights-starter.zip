import React, {useState} from 'react';

function Tile({title, value, color, onPlay}){
  return (
    <div style={{padding:20, margin:10, borderRadius:8, background:'#fff', width:220, boxShadow:'0 2px 6px rgba(0,0,0,0.1)'}}>
      <h3>{title}</h3>
      <div style={{fontSize:32}}>{value}</div>
      <button onClick={onPlay} style={{marginTop:10}}>Play explanation</button>
    </div>
  )
}

export default function App(){
  const [district, setDistrict] = useState('Pune');
  return (
    <div style={{fontFamily:'Arial, sans-serif', padding:24, background:'#f0f2f5', minHeight:'100vh'}}>
      <h1>Our Voice, Our Rights — Maharashtra</h1>
      <div>
        <label>District: </label>
        <input value={district} onChange={e=>setDistrict(e.target.value)} />
      </div>
      <div style={{display:'flex', marginTop:20}}>
        <Tile title="Workdays" value="5" onPlay={()=>alert('Play Workdays audio (placeholder)')} />
        <Tile title="Payments" value="On-time" onPlay={()=>alert('Play Payments audio (placeholder)')} />
        <Tile title="Wage Delays" value="Low" onPlay={()=>alert('Play Wage delays audio (placeholder)')} />
      </div>
      <p style={{marginTop:20}}>This is a starter UI. Replace with real data from the backend.</p>
    </div>
  )
}
