const express = require('express');
const app = express();
app.use(express.json());

app.get('/health', (req, res) => res.json({ok: true, ts: new Date()}));

// Placeholder district summary route
app.get('/api/district/:state/:district', async (req, res) => {
  const { state, district } = req.params;
  // TODO: replace with DB query
  return res.json({ state, district, summary: { workdays: 5, payments: 'on-time', wage_delays: 'low' } });
});

const port = process.env.PORT || 8000;
app.listen(port, ()=> console.log('backend listening', port));
