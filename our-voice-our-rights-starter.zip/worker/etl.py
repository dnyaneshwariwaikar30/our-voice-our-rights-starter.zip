import os, time, requests, json
from urllib.parse import urljoin

API_URL = os.getenv('DATA_API_URL', 'https://data.gov.in/api/datastore/resource.json')
# This is a skeleton ETL loop - replace with data.gov.in specifics and API key handling
def fetch():
    try:
        r = requests.get(API_URL, timeout=20)
        r.raise_for_status()
        print('fetched', len(r.text))
        # Transform & upsert into Postgres (not implemented)
    except Exception as e:
        print('fetch error', e)

if __name__ == '__main__':
    while True:
        fetch()
        time.sleep(60*60*6)
