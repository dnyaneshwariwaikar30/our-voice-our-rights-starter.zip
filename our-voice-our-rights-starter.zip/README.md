# Our Voice, Our Rights — Starter Repo

Minimal starter repo for the MGNREGA district performance viewer (Maharashtra sample).

## Contents
- docker-compose.yml
- backend/ (Node + Express minimal API)
- worker/ (Python ETL sketch)
- frontend/ (React placeholder)

## Quick start (Ubuntu VPS)
1. Install Docker & Docker Compose.
2. Clone or copy this repo to the VPS.
3. Edit backend/.env and worker/.env with appropriate DB credentials and DATA_API_URL.
4. `docker compose up -d --build`
5. Open `http://<VPS_IP>:3000` for frontend and `http://<VPS_IP>:8000/health` for backend health.

## Notes
- Replace ETL and data mapping in worker/etl.py with proper handling of data.gov.in API.
- Create TTS audio files and point frontend to them or serve via backend.
